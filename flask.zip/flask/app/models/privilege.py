from app import db

class Privilege(db.Model):
    role_id = db.Column(db.Integer, db.ForeignKey("role.id"), primary_key=True, nullable=False)
    resource_id = db.Column(db.Integer, db.ForeignKey("resource.id"), primary_key=True, nullable=False)
    allow = db.Column(db.Boolean, nullable=False)

    def __repr__(self):
        return '<nome %r>' % self.nome

    def to_dict(self):
        return {
            "role_id": self.role_id,
            "resource_id": self.resource_id,
            "allow": self.allow
        }