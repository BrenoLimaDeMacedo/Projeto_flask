from app import app, db
from flask import request, jsonify
from app import Role

@app.route("/role/list", methods=["GET"])
def role_list():
    roles = Role.query.all()
    arr = []

    for role in roles:
        arr.append(role.to_dict())

    return jsonify({"elements": arr, "error": False})

@app.route("/role/add", methods=["POST"])
def role_add():
    data = request.get_json()

    if "id" not in data or data["id"] is None:
        return jsonify({"error": True, "message": "username não foi retornado"}), 400

    if "nome" not in data or data["nome"] is None:
        return jsonify({"error": True, "message": "email não foi retornado"}), 400

    role = Role(id=data["id"], nome=data["nome"])

    try:
        db.session.add(role)
        db.session.commit()

        return jsonify({"error": False})


    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "O email ou username já existe"})
