from app import app, db
from flask import request, jsonify
from app import User

@app.route("/user/list", methods=["GET"])
def user_list():
    users = user.query.all()
    arr = []

    for user in users:
        arr.append(user.to_dict())

    return jsonify({"elements": arr, "error": False})

@app.route("/user/add", methods=["POST"])
def user_add():
    data = request.get_json()

    if "id" not in data or data["id"] is None:
        return jsonify({"error": True, "message": "id não foi retornado"}), 400

    if "email" not in data or data["email"] is None:
        return jsonify({"error": True, "message": "email não foi retornado"}), 400

    if "password" not in data or data["password"] is None:
        return jsonify({"error": True, "message": "password não foi retornado"}), 400

    user = User(id=data["id"], email=data["email"], password=data["password"], role_id=data["role_id"])

    try:
        db.session.add(user)
        db.session.commit()

        return jsonify({"error": False})


    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "O email ou username já existe"})
